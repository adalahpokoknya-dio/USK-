<?php
// Memastikan user hanya dapat melihat dan mengunggah bukti pada pesanannya sendiri.

require_once 'config/auth.php';
requireUser();

$uid = $_SESSION['user']['id'];
$id = (int) ($_GET['id'] ?? 0);

$stmt = $conn->prepare(
    'SELECT * FROM orders WHERE id_order = ? AND id_user = ?'
);

$stmt->bind_param('ii', $id, $uid);
$stmt->execute();

$o = $stmt->get_result()->fetch_assoc();

if (!$o) {
    flash('error', 'Pesanan tidak ditemukan.');
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($o['status'] !== 'Menunggu Pembayaran') {
        flash('error', 'Bukti tidak dapat diubah pada status ini.');
    } elseif (empty($_FILES['bukti']['name']) || $_FILES['bukti']['error'] !== UPLOAD_ERR_OK) {
        flash('error', 'Pilih file bukti pembayaran.');
    } else {
        $file = $_FILES['bukti'];
        $allowed = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp'
        ];

        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);

        if (!isset($allowed[$mime]) || $file['size'] > 2 * 1024 * 1024) {
            flash('error', 'File harus JPG, PNG, atau WEBP maksimal 2 MB.');
        } else {
            $name = 'payment_' . $id . '_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
            $dir = __DIR__ . '/uploads/payments';

            if (!is_dir($dir)) {
                mkdir($dir, 0775, true);
            }

            move_uploaded_file($file['tmp_name'], $dir . '/' . $name);

            $status = 'Menunggu Verifikasi';

            $up = $conn->prepare(
                'UPDATE orders
                 SET bukti_pembayaran = ?, status = ?
                 WHERE id_order = ? AND id_user = ?'
            );

            $up->bind_param('ssii', $name, $status, $id, $uid);
            $up->execute();

            flash('success', 'Bukti pembayaran dikirim.');
            header('Location: order_success.php?id=' . $id);
            exit;
        }
    }
}

$statusLabel = $o['status'] === 'Disetujui' ? 'Diterima' : $o['status'];
$pageTitle = 'Pesanan Berhasil';

require 'includes/header.php';
?>

<!-- Halaman pasca checkout sekaligus menyediakan upload bukti pembayaran. -->

<div class="card shadow-sm auth-card">
    <div class="card-body p-4">
        <h1 class="h3">Pesanan #<?= e($o['id_order']) ?></h1>

        <p>
            Total:
            <strong class="price">
                Rp<?= number_format($o['total_harga'], 0, ',', '.') ?>
            </strong>
        </p>

        <p>
            Metode pembayaran:
            <strong><?= e($o['metode_pembayaran'] ?: 'Belum dipilih') ?></strong>
        </p>

        <p>
            Alamat pengiriman: <br>
            <?= nl2br(e($o['alamat_pengiriman'] ?: '-')) ?>
        </p>

        <p>
            Status:
            <span class="badge text-bg-info"><?= e($statusLabel) ?></span>
        </p>

        <p>
            <a class="btn btn-outline-primary btn-sm" href="receipt.php?id=<?= e($o['id_order']) ?>">
                Unduh Detail Pesanan PDF
            </a>

            <?php if ($o['bukti_pembayaran']): ?>
                <a class="btn btn-success btn-sm" href="payment_receipt.php?id=<?= e($o['id_order']) ?>">
                    Unduh Receipt Pembayaran PDF
                </a>
            <?php endif; ?>

            <a class="btn btn-light btn-sm" href="pesanan.php">
                Lihat Semua Pesanan
            </a>
        </p>

        <?php if (in_array($o['status'], ['Menunggu Pembayaran', 'Menunggu Verifikasi'], true)): ?>
            <a class="btn btn-outline-danger btn-sm mb-3" href="batalkan_pesanan.php?id=<?= e($o['id_order']) ?>">
                Batalkan Pesanan
            </a>
        <?php endif; ?>

        <?php if ($o['bukti_pembayaran']): ?>
            <p>
                Bukti telah dikirim:
                <a target="_blank" href="uploads/payments/<?= e($o['bukti_pembayaran']) ?>">
                    Lihat bukti
                </a>
            </p>
        <?php endif; ?>

        <?php if ($o['status'] === 'Menunggu Pembayaran'): ?>
            <hr>
            <h2 class="h5">Unggah Bukti Pembayaran</h2>

            <form method="post" enctype="multipart/form-data">
                <input
                    class="form-control mb-3"
                    type="file"
                    name="bukti"
                    accept="image/jpeg,image/png,image/webp"
                    required
                >
                <button class="btn btn-primary">Kirim Bukti</button>
            </form>
        <?php endif; ?>

        <?php if ($o['catatan_admin']): ?>
            <p class="alert alert-secondary mt-3">
                Catatan admin: <?= e($o['catatan_admin']) ?>
            </p>
        <?php endif; ?>

        <?php if ($o['alasan_pembatalan']): ?>
            <p class="alert alert-secondary mt-3">
                Alasan pembatalan: <?= e($o['alasan_pembatalan']) ?>
            </p>
        <?php endif; ?>
    </div>
</div>

<?php require 'includes/footer.php'; ?>