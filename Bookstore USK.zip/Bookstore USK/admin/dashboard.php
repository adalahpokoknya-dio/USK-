<?php
// Mengambil angka ringkasan dari tabel inti untuk pemantauan admin.

$pageTitle = 'Dashboard';
require 'includes/header.php';

$counts = [];
foreach (['buku' => 'Buku', 'user' => 'User', 'orders' => 'Pesanan', 'pesan' => 'Pesan'] as $table => $label) {
    $counts[$label] = (int) $conn->query("SELECT COUNT(*) AS total FROM $table")->fetch_assoc()['total'];
}
?>

<!-- Kartu statistik data utama aplikasi. -->

<h1 class="h3 mb-4">Dashboard</h1>

<div class="row g-3">
    <?php foreach ($counts as $label => $total): ?>
        <div class="col-md-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <p class="text-muted mb-1"><?= e($label) ?></p>
                    <strong class="display-6 text-primary"><?= $total ?></strong>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="mt-4">
    <a class="btn btn-primary" href="order.php">Kelola Pesanan</a>
</div>

<?php require 'includes/footer.php'; ?>
