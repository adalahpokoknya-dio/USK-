<?php
require_once __DIR__ . '/../../config/auth.php';
requireAdmin();
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= isset($pageTitle) ? e($pageTitle) . ' | ' : '' ?>Admin BookStore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>

<!-- Navigasi panel admin menuju setiap modul manajemen. -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand fw-bold" href="dashboard.php">BookStore Admin</a>
        <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#adminNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="adminNav">
            <ul class="navbar-nav ms-auto">
                <?php
                $menu = [
                    'Kategori' => 'kategori.php',
                    'Buku' => 'buku.php',
                    'User' => 'user.php',
                    'Pesanan' => 'order.php',
                    'Pesan' => 'pesan.php',
                    'Keluar' => 'logout.php'
                ];

                foreach ($menu as $nama => $link):
                ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= e($link) ?>"><?= e($nama) ?></a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</nav>

<main class="py-4">
    <div class="container">
        <?php foreach (['success' => 'success', 'error' => 'danger'] as $type => $class): ?>
            <?php if ($m = flash($type)): ?>
                <div class="alert alert-<?= $class ?>"><?= e($m) ?></div>
            <?php endif; ?>
        <?php endforeach; ?>