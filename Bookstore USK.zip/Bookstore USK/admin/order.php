<?php
// Admin verifikasi pembayaran
require_once '../config/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) ($_POST['id_order'] ?? 0);
    $status = $_POST['status'] ?? '';
    $note = trim($_POST['catatan_admin'] ?? '');
    $allowed = ['Disetujui', 'Ditolak'];

    if (!in_array($status, $allowed, true)) {
        flash('error', 'Status verifikasi tidak valid.');
    } else {
        $stmt = $conn->prepare("UPDATE orders SET status=?,catatan_admin=? WHERE id_order=? AND status='Menunggu Verifikasi'");
        $stmt->bind_param('ssi', $status, $note, $id);
        $stmt->execute();
        flash($stmt->affected_rows ? 'success' : 'error', $stmt->affected_rows ? 'Status pesanan diperbarui.' : 'Pesanan tidak dapat diverifikasi.');
    }

    header('Location: order.php' . (isset($_GET['id']) ? '?id=' . (int) $_GET['id'] : ''));
    exit;
}

$id = (int) ($_GET['id'] ?? 0);
$detail = null;

if ($id) {
    $stmt = $conn->prepare('SELECT o.*,u.nama,u.email,u.alamat,u.nomor_telepon FROM orders o JOIN user u ON u.id_user=o.id_user WHERE o.id_order=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $detail = $stmt->get_result()->fetch_assoc();

    if ($detail) {
        $items = $conn->prepare('SELECT od.*,b.judul_buku FROM order_detail od JOIN buku b ON b.id_buku=od.id_buku WHERE od.id_order=?');
        $items->bind_param('i', $id);
        $items->execute();
        $items = $items->get_result();
    }
}

$pageTitle = 'Pesanan';
require 'includes/header.php';
$rows = $conn->query('SELECT o.*,u.nama FROM orders o JOIN user u ON u.id_user=o.id_user ORDER BY o.tanggal_order DESC');
?>

<!-- Tabel pesanan membuka detail pembeli, buku, bukti, dan form verifikasi. -->
<h1 class="h3 mb-3">Manajemen Pesanan</h1>
<div class="card shadow-sm table-responsive">
    <table class="table mb-0">
        <tr>
            <th>ID</th><th>Pembeli</th><th>Tanggal</th><th>Metode</th><th>Total</th><th>Status</th><th></th>
        </tr>
        <?php while ($o = $rows->fetch_assoc()): ?>
            <tr>
                <td>#<?= $o['id_order'] ?></td>
                <td><?= e($o['nama']) ?></td>
                <td><?= e($o['tanggal_order']) ?></td>
                <td><?= e($o['metode_pembayaran'] ?: '-') ?></td>
                <td>Rp<?= number_format($o['total_harga'], 0, ',', '.') ?></td>
                <td><span class="badge text-bg-info"><?= e($o['status']) ?></span></td>
                <td><a class="btn btn-sm btn-outline-primary" href="?id=<?= $o['id_order'] ?>">Detail</a></td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php if ($detail): ?>
    <div class="card shadow-sm mt-4">
        <div class="card-body">
            <h2 class="h4">Pesanan #<?= $detail['id_order'] ?></h2>
            <p>
                <strong><?= e($detail['nama']) ?></strong> · <?= e($detail['email']) ?><br>
                Nomor telepon: <?= e($detail['nomor_telepon']) ?><br>
                Metode: <strong><?= e($detail['metode_pembayaran'] ?: '-') ?></strong><br>
                Alamat pengiriman:<br>
                <?= nl2br(e($detail['alamat_pengiriman'] ?: $detail['alamat'])) ?>
            </p>

            <h3 class="h5">Detail Buku</h3>
            <ul>
                <?php while ($i = $items->fetch_assoc()): ?>
                    <li><?= e($i['judul_buku']) ?> × <?= $i['jumlah'] ?> — Rp<?= number_format($i['subtotal'], 0, ',', '.') ?></li>
                <?php endwhile; ?>
            </ul>

            <?php if ($detail['bukti_pembayaran']): ?>
                <p>
                    <a target="_blank" class="btn btn-outline-primary" href="../uploads/payments/<?= e($detail['bukti_pembayaran']) ?>">Lihat Bukti Pembayaran</a>
                </p>
            <?php endif; ?>

            <?php if ($detail['status'] === 'Menunggu Verifikasi'): ?>
                <form method="post" class="row g-2">
                    <input type="hidden" name="id_order" value="<?= $detail['id_order'] ?>">
                    <div class="col-md-7">
                        <input class="form-control" name="catatan_admin" placeholder="Catatan admin (opsional)">
                    </div>
                    <div class="col-md-5">
                        <button class="btn btn-success" name="status" value="Disetujui">Setujui</button>
                        <button class="btn btn-danger" name="status" value="Ditolak">Tolak</button>
                    </div>
                </form>
            <?php elseif ($detail['catatan_admin']): ?>
                <p class="alert alert-secondary">Catatan: <?= e($detail['catatan_admin']) ?></p>
            <?php endif; ?>

            <?php if ($detail['alasan_pembatalan']): ?>
                <p class="alert alert-warning mt-3">Alasan pembatalan user: <?= e($detail['alasan_pembatalan']) ?></p>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<?php require 'includes/footer.php'; ?>
