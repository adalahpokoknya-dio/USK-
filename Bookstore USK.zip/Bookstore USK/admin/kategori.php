<?php
// CRUD kategori bindparam.

require_once '../config/auth.php';
requireAdmin();

$edit = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['nama_kategori'] ?? '');
    $id = (int) ($_POST['id_kategori'] ?? 0);

   if (!$name) {
    flash('error', 'Nama kategori wajib diisi.');
} else {
    // Mengecek apakah nama kategori sudah digunakan.
    $check = $conn->prepare(
        'SELECT id_kategori FROM kategori WHERE nama_kategori = ? AND id_kategori != ?'
    );
    $check->bind_param('si', $name, $id);
    $check->execute();

    $exists = $check->get_result()->num_rows;

    if ($exists) {
        flash('error', 'Kategori buku sudah ada.');
    } elseif ($id) {
        $stmt = $conn->prepare(
            'UPDATE kategori SET nama_kategori=? WHERE id_kategori=?'
        );
        $stmt->bind_param('si', $name, $id);
        $stmt->execute();

        flash('success', 'Kategori diperbarui.');
    } else {
        $stmt = $conn->prepare(
            'INSERT INTO kategori (nama_kategori) VALUES (?)'
        );
        $stmt->bind_param('s', $name);
        $stmt->execute();

        flash('success', 'Kategori ditambahkan.');
    }
}

    header('Location: kategori.php');
    exit;
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = $conn->prepare('DELETE FROM kategori WHERE id_kategori=?');
    $stmt->bind_param('i', $id);

    flash($stmt->execute() ? 'success' : 'error',
        $stmt->affected_rows > 0
            ? 'Kategori dihapus.'
            : 'Kategori tidak dapat dihapus karena masih dipakai buku.'
    );

    header('Location: kategori.php');
    exit;
}

if (isset($_GET['edit'])) {
    $id = (int) $_GET['edit'];
    $stmt = $conn->prepare('SELECT * FROM kategori WHERE id_kategori=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $edit = $stmt->get_result()->fetch_assoc();
}

$pageTitle = 'Kategori';
require 'includes/header.php';

$rows = $conn->query('SELECT * FROM kategori ORDER BY nama_kategori');
?>

<!-- Form crud kategori, tabel menampilkan daftar kategori. -->

<h1 class="h3">Manajemen Kategori</h1>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <form method="post">
                    <input type="hidden" name="id_kategori" value="<?= e($edit['id_kategori'] ?? '') ?>">

                    <label class="form-label"><?= $edit ? 'Ubah' : 'Tambah' ?> kategori</label>
                    <input required class="form-control mb-3" name="nama_kategori" value="<?= e($edit['nama_kategori'] ?? '') ?>">

                    <button class="btn btn-primary">Simpan</button>
                    <?php if ($edit): ?>
                        <a class="btn btn-light" href="kategori.php">Batal</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow-sm table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr><th>ID</th><th>Nama</th><th>Aksi</th></tr>
                </thead>
                <tbody>
                    <?php while ($r = $rows->fetch_assoc()): ?>
                        <tr>
                            <td><?= $r['id_kategori'] ?></td>
                            <td><?= e($r['nama_kategori']) ?></td>
                            <td>
                                <a class="btn btn-sm btn-outline-primary" href="?edit=<?= $r['id_kategori'] ?>">Edit</a>
                                <a class="btn btn-sm btn-outline-danger confirm-delete" href="?delete=<?= $r['id_kategori'] ?>">Hapus</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require 'includes/footer.php'; ?>