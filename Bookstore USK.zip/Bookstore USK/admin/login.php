<?php
// Login khusus admin memakai hash sql admin.

require_once '../config/auth.php';

if (!empty($_SESSION['admin'])) {
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare('SELECT * FROM admin WHERE email=?');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $a = $stmt->get_result()->fetch_assoc();

    if ($a && password_verify($password, $a['password'])) {
        session_regenerate_id(true);
        $_SESSION['admin'] = [
            'id' => $a['id_admin'],
            'nama' => $a['nama'],
            'email' => $a['email']
        ];

        header('Location: dashboard.php');
        exit;
    }

    flash('error', 'Email atau password admin salah.');
}
?>

<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Admin | BookStore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <main class="container py-5">
        <div class="card shadow-sm auth-card">
            <div class="card-body p-4">
                <h1 class="h3">Login Admin</h1>

                <?php if ($m = flash('error')): ?>
                    <div class="alert alert-danger"><?= e($m) ?></div>
                <?php endif; ?>

                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input class="form-control" type="email" name="email" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input class="form-control" type="password" name="password" required>
                    </div>

                    <button class="btn btn-primary w-100">Masuk</button>
                </form>

                <p class="text-center small mt-3 mb-0">
                    <a href="../index.php">← Kembali ke toko</a>
                </p>
            </div>
        </div>
    </main>
</body>
</html>