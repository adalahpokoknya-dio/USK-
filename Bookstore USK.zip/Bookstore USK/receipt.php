<?php
// receipt PDF sederhana dan membatasi hanya untuk user

require_once 'config/auth.php';
requireUser();

$userId = $_SESSION['user']['id'];
$orderId = (int) ($_GET['id'] ?? 0);

$orderStmt = $conn->prepare(
    'SELECT o.*, u.nama, u.email
     FROM orders o
     JOIN user u ON u.id_user = o.id_user
     WHERE o.id_order = ? AND o.id_user = ?'
);

$orderStmt->bind_param('ii', $orderId, $userId);
$orderStmt->execute();

$order = $orderStmt->get_result()->fetch_assoc();

if (!$order) {
    http_response_code(404);
    exit('Pesanan tidak ditemukan.');
}

$itemStmt = $conn->prepare(
    'SELECT od.jumlah, od.subtotal, b.judul_buku
     FROM order_detail od
     JOIN buku b ON b.id_buku = od.id_buku
     WHERE od.id_order = ?'
);

$itemStmt->bind_param('i', $orderId);
$itemStmt->execute();

$items = $itemStmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Merapihkan dan membatasi lebar teks pdf.
function pdfText($value) {
    $value = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', (string) $value);
    $value = preg_replace('/[^\x20-\x7E]/', '', $value);

    return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $value);
}

function pdfLine($text, $x, $y, $size = 10) {
    return "BT /F1 $size Tf $x $y Td (" . pdfText($text) . ") Tj ET\n";
}

$content = "0.10 0.45 0.70 rg 40 770 515 2 re f\n";
$content .= pdfLine('BOOKSTORE - RECEIPT PESANAN', 40, 735, 18);
$content .= pdfLine('Nomor Pesanan: #' . $order['id_order'], 40, 705, 10);
$content .= pdfLine('Tanggal: ' . $order['tanggal_order'], 40, 690, 10);
$content .= pdfLine('Pelanggan: ' . $order['nama'] . ' (' . $order['email'] . ')', 40, 675, 10);
$content .= pdfLine('Metode: ' . ($order['metode_pembayaran'] ?: 'Belum dipilih'), 40, 660, 10);
$content .= pdfLine('Status: ' . ($order['status'] === 'Disetujui' ? 'Diterima' : $order['status']), 40, 645, 10);
$content .= "0.85 G 40 632 m 555 632 l S\n";

$y = 610;
$content .= pdfLine('RINCIAN BUKU', 40, $y, 12);
$y -= 22;

foreach ($items as $item) {
    $title = strlen($item['judul_buku']) > 55
        ? substr($item['judul_buku'], 0, 52) . '...'
        : $item['judul_buku'];

    $content .= pdfLine($title . ' x' . $item['jumlah'], 40, $y, 10);
    $content .= pdfLine('Rp' . number_format($item['subtotal'], 0, ',', '.'), 450, $y, 10);
    $y -= 18;
}

$content .= "0.85 G 40 " . ($y + 5) . " m 555 " . ($y + 5) . " l S\n";
$y -= 18;

$content .= pdfLine('TOTAL: Rp' . number_format($order['total_harga'], 0, ',', '.'), 360, $y, 13);
$content .= pdfLine('Receipt ini dibuat otomatis oleh BookStore.', 40, 60, 9);

// Menyusun pdf dan memakai pdf 1.4 .
$objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    "<< /Length " . strlen($content) . " >>\nstream\n$content\nendstream"
];

$pdf = "%PDF-1.4\n";
$offsets = [0];

foreach ($objects as $number => $object) {
    $offsets[] = strlen($pdf);
    $pdf .= ($number + 1) . " 0 obj\n$object\nendobj\n";
}

$xref = strlen($pdf);
$pdf .= "xref\n0 " . (count($objects) + 1) . "\n0000000000 65535 f \n";

for ($i = 1; $i <= count($objects); $i++) {
    $pdf .= sprintf('%010d 00000 n ', $offsets[$i]) . "\n";
}

$pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\nstartxref\n$xref\n%%EOF";

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="receipt-order-' . $orderId . '.pdf"');
header('Content-Length: ' . strlen($pdf));

echo $pdf;
exit;
?>