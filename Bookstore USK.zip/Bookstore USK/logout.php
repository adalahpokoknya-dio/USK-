<?php

// Menghapus seluruh session login user dan mengembalikan pengunjung ke beranda.

require_once 'config/auth.php';

unset($_SESSION['user']);

session_regenerate_id(true);

header('Location: index.php');
exit;

?>
