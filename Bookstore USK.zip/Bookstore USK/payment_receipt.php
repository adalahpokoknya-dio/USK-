<?php
// File mandiri ini hanya membuat bon transaksi PDF bagi pesanan yang telah disetujui admin.

require_once 'config/auth.php';
requireUser();

// Mengambil pesanan berdasarkan ID sekaligus memastikan pesanan tersebut milik user yang login.
$userId = $_SESSION['user']['id'];
$orderId = (int) ($_GET['id'] ?? 0);

$orderStmt = $conn->prepare(
    'SELECT o.*, u.nama, u.email
     FROM orders o
     JOIN user u ON u.id_user = o.id_user
     WHERE o.id_order = ? AND o.id_user = ?'
);

$orderStmt->bind_param('ii', $orderId, $userId);
$orderStmt->execute();

$order = $orderStmt->get_result()->fetch_assoc();

// Menolak akses jika order tidak ada, bukan milik user, atau belum diterima admin.
if (!$order || $order['status'] !== 'Disetujui') {
    http_response_code(403);
    exit('Bon transaksi hanya tersedia untuk pesanan yang telah diterima admin.');
}

// Mengambil rincian buku agar bon memuat transaksi secara lengkap.
$itemStmt = $conn->prepare(
    'SELECT od.jumlah, od.subtotal, b.judul_buku
     FROM order_detail od
     JOIN buku b ON b.id_buku = od.id_buku
     WHERE od.id_order = ?'
);

$itemStmt->bind_param('i', $orderId);
$itemStmt->execute();

$items = $itemStmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Mengonversi teks UTF-8 ke karakter aman PDF dan menghindari karakter pengganggu sintaks PDF.
function transactionPdfText($value) {
    $value = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', (string) $value);
    $value = preg_replace('/[^\x20-\x7E]/', '', $value);

    return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $value);
}

// Menambahkan satu baris teks ke stream PDF dengan font Helvetica bawaan PDF.
function transactionPdfLine($text, $x, $y, $size = 10) {
    return "BT /F1 $size Tf $x $y Td (" . transactionPdfText($text) . ") Tj ET\n";
}

// Menyiapkan isi PDF A4 dengan informasi pembeli, status diterima, dan daftar buku.
$content = "0.10 0.45 0.70 rg 40 770 515 2 re f\n";
$content .= transactionPdfLine('BOOKSTORE - BON TRANSAKSI', 40, 735, 18);
$content .= transactionPdfLine('TRANSAKSI DITERIMA ADMIN', 40, 710, 11);
$content .= transactionPdfLine('Nomor Transaksi: #' . $order['id_order'], 40, 682, 10);
$content .= transactionPdfLine('Tanggal Pesan: ' . $order['tanggal_order'], 40, 667, 10);
$content .= transactionPdfLine('Nama Pembeli: ' . $order['nama'], 40, 652, 10);
$content .= transactionPdfLine('Email: ' . $order['email'], 40, 637, 10);
$content .= transactionPdfLine('Metode Pembayaran: ' . ($order['metode_pembayaran'] ?: 'Tidak tercatat'), 40, 622, 10);
$content .= "0.85 G 40 608 m 555 608 l S\n";

$y = 586;
$content .= transactionPdfLine('RINCIAN PEMBELIAN', 40, $y, 12);
$y -= 22;

foreach ($items as $item) {
    // Membatasi judul agar baris item tidak melewati kolom subtotal.
    $title = strlen($item['judul_buku']) > 52
        ? substr($item['judul_buku'], 0, 49) . '...'
        : $item['judul_buku'];

    $content .= transactionPdfLine($title . ' x' . $item['jumlah'], 40, $y, 10);
    $content .= transactionPdfLine('Rp' . number_format($item['subtotal'], 0, ',', '.'), 445, $y, 10);
    $y -= 18;
}

$content .= "0.85 G 40 " . ($y + 5) . " m 555 " . ($y + 5) . " l S\n";
$y -= 18;

$content .= transactionPdfLine('TOTAL DIBAYAR: Rp' . number_format($order['total_harga'], 0, ',', '.'), 330, $y, 13);
$content .= transactionPdfLine('Status: DITERIMA', 40, 92, 11);
$content .= transactionPdfLine('Terima kasih telah berbelanja di BookStore.', 40, 70, 9);
$content .= transactionPdfLine('Dokumen ini dibuat otomatis dan berlaku sebagai bon transaksi.', 40, 56, 8);

// Membuat struktur PDF 1.4 sederhana tanpa mengubah file receipt.php yang sudah ada.
$objects = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
    "<< /Length " . strlen($content) . " >>\nstream\n$content\nendstream",
];

$pdf = "%PDF-1.4\n";
$offsets = [0];

foreach ($objects as $number => $object) {
    $offsets[] = strlen($pdf);
    $pdf .= ($number + 1) . " 0 obj\n$object\nendobj\n";
}

$xref = strlen($pdf);
$pdf .= "xref\n0 " . (count($objects) + 1) . "\n0000000000 65535 f \n";

for ($i = 1; $i <= count($objects); $i++) {
    $pdf .= sprintf('%010d 00000 n ', $offsets[$i]) . "\n";
}

$pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\nstartxref\n$xref\n%%EOF";

// Memaksa browser mengunduh bon sebagai file PDF.
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="bon-transaksi-order-' . $orderId . '.pdf"');
header('Content-Length: ' . strlen($pdf));

echo $pdf;
exit;
?>