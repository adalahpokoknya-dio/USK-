<?php
// Memuat layout serta mengambil enam buku terbaru untuk beranda.

$pageTitle = 'Beranda';
require_once 'includes/header.php';

$books = $conn->query(
    'SELECT b.*, k.nama_kategori
     FROM buku b
     JOIN kategori k ON k.id_kategori = b.id_kategori
     ORDER BY b.id_buku DESC
     LIMIT 6'
);
?>

<!-- Hero memperkenalkan aplikasi dan mengarahkan pelanggan ke katalog. -->

<section class="hero mb-5 text-center">
    <h1 class="display-5 fw-bold">Buku untuk setiap perjalanan</h1>

    <p class="lead text-muted">
        Jelajahi koleksi pilihan BookStore dengan pengalaman
        belanja yang sederhana.
    </p>

    <a href="buku.php" class="btn btn-primary btn-lg">
        Lihat Katalog
    </a>
</section>

<h2 class="h3 mb-3">Buku Terbaru</h2>

<div class="row g-4">
    <?php while ($b = $books->fetch_assoc()) : ?>
        <div class="col-sm-6 col-lg-4">
            <div class="card book-card shadow-sm">
                <img
                    class="book-image"
                    src="<?= $b['gambar'] ? 'uploads/books/' . e($b['gambar']) : 'https://placehold.co/600x400/eaf7ff/2196d3?text=BookStore' ?>"
                    alt="Sampul <?= e($b['judul_buku']) ?>"
                >

                <div class="card-body">
                    <span class="badge text-bg-info mb-2">
                        <?= e($b['nama_kategori']) ?>
                    </span>

                    <h3 class="h5"><?= e($b['judul_buku']) ?></h3>

                    <p class="text-muted small mb-2">
                        <?= e($b['penulis']) ?>
                    </p>

                    <p class="price">
                        Rp<?= number_format($b['harga'], 0, ',', '.') ?>
                    </p>

                    <a
                        class="btn btn-outline-primary w-100"
                        href="detail_buku.php?id=<?= $b['id_buku'] ?>"
                    >
                        Detail
                    </a>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<?php require_once 'includes/footer.php'; ?>