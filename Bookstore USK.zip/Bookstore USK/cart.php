<?php
// keranjang hanya untuk user yang sudah login.

require_once 'config/auth.php';
requireUser();

$uid = $_SESSION['user']['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $cart = (int) ($_POST['id_cart'] ?? 0);

    if ($action === 'update') {
        $jumlah = max(1, (int) ($_POST['jumlah'] ?? 1));

        $stmt = $conn->prepare(
            'UPDATE cart c
             JOIN buku b ON b.id_buku = c.id_buku
             SET c.jumlah = ?
             WHERE c.id_cart = ?
             AND c.id_user = ?
             AND ? <= b.stok'
        );

        $stmt->bind_param('iiii', $jumlah, $cart, $uid, $jumlah);
        $stmt->execute();

        flash(
            $stmt->affected_rows ? 'success' : 'error',
            $stmt->affected_rows
                ? 'Keranjang diperbarui.'
                : 'Jumlah tidak valid atau melebihi stok.'
        );
    }

    if ($action === 'delete') {
        $stmt = $conn->prepare(
            'DELETE FROM cart
             WHERE id_cart = ?
             AND id_user = ?'
        );

        $stmt->bind_param('ii', $cart, $uid);
        $stmt->execute();

        flash('success', 'Item dihapus.');
    }

    header('Location: cart.php');
    exit;
}

$stmt = $conn->prepare(
    'SELECT c.*, b.judul_buku, b.harga, b.stok
     FROM cart c
     JOIN buku b ON b.id_buku = c.id_buku
     WHERE c.id_user = ?'
);

$stmt->bind_param('i', $uid);
$stmt->execute();
$items = $stmt->get_result();

$total = 0;
$pageTitle = 'Keranjang';

require 'includes/header.php';
?>

<!-- aksi cart tambah hapus. -->

<h1 class="h3 mb-3">Keranjang Belanja</h1>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Buku</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                    <th></th>
                </tr>
            </thead>

            <tbody>
                <?php while ($i = $items->fetch_assoc()) : ?>
                    <?php
                    $sub = $i['harga'] * $i['jumlah'];
                    $total += $sub;
                    ?>

                    <tr>
                        <td><?= e($i['judul_buku']) ?></td>
                        <td>Rp<?= number_format($i['harga'], 0, ',', '.') ?></td>
                        <td>
                            <form method="post" class="d-flex gap-1">
                                <input type="hidden" name="action" value="update">
                                <input type="hidden" name="id_cart" value="<?= $i['id_cart'] ?>">
                                <input
                                    class="form-control form-control-sm"
                                    style="width:70px"
                                    type="number"
                                    name="jumlah"
                                    min="1"
                                    max="<?= $i['stok'] ?>"
                                    value="<?= $i['jumlah'] ?>"
                                >
                                <button class="btn btn-sm btn-outline-primary">Ubah</button>
                            </form>
                        </td>
                        <td>Rp<?= number_format($sub, 0, ',', '.') ?></td>
                        <td>
                            <form method="post">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id_cart" value="<?= $i['id_cart'] ?>">
                                <button class="btn btn-sm btn-outline-danger confirm-delete">
                                    Hapus
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>

                <?php if ($total === 0) : ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">
                            Keranjang masih kosong.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="card-body text-end">
        <strong class="h5">
            Total: Rp<?= number_format($total, 0, ',', '.') ?>
        </strong>

        <?php if ($total > 0) : ?>
            <a class="btn btn-primary ms-3" href="checkout.php">
                Checkout
            </a>
        <?php endif; ?>
    </div>
</div>

<?php require 'includes/footer.php'; ?>