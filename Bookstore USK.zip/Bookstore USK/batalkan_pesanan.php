<?php
// User bisa melakukakn cancel order jika pesanan belum acc.
require_once 'config/auth.php';
requireUser();

$userId = $_SESSION['user']['id'];
$orderId = (int) ($_GET['id'] ?? $_POST['id_order'] ?? 0);

$orderStmt = $conn->prepare('SELECT id_order, total_harga, status FROM orders WHERE id_order=? AND id_user=?');
$orderStmt->bind_param('ii', $orderId, $userId);
$orderStmt->execute();
$order = $orderStmt->get_result()->fetch_assoc();

$cancelableStatuses = ['Menunggu Pembayaran', 'Menunggu Verifikasi'];

// Pesanan hanya dapat dibatalkan user jika belum acc.
if (!$order || !in_array($order['status'], $cancelableStatuses, true)) {
    flash('error', 'Pesanan tidak dapat dibatalkan karena sudah memiliki keputusan admin atau tidak ditemukan.');
    header('Location: pesanan.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reason = trim($_POST['alasan_pembatalan'] ?? '');
    // Limit form alasan.
    $reason = mb_substr($reason, 0, 1000);

    try {
        $conn->begin_transaction();
        // Mengunci pesanan supaya tidak konflik dengan admin.
        $lockStmt = $conn->prepare('SELECT status FROM orders WHERE id_order=? AND id_user=? FOR UPDATE');
        $lockStmt->bind_param('ii', $orderId, $userId);
        $lockStmt->execute();
        $lockedOrder = $lockStmt->get_result()->fetch_assoc();

        if (!$lockedOrder || !in_array($lockedOrder['status'], $cancelableStatuses, true)) {
            throw new Exception('Pesanan sudah tidak dapat dibatalkan.');
        }

        // Menandai pembatalan dan menyimpan alasan untuk dilihat.
        $status = 'Dibatalkan';
        $updateStmt = $conn->prepare('UPDATE orders SET status=?, alasan_pembatalan=? WHERE id_order=? AND id_user=?');
        $updateStmt->bind_param('ssii', $status, $reason, $orderId, $userId);
        $updateStmt->execute();

        // Mengembalikan stok buku yang di batalkan.
        $detailStmt = $conn->prepare('SELECT id_buku, jumlah FROM order_detail WHERE id_order=?');
        $detailStmt->bind_param('i', $orderId);
        $detailStmt->execute();
        $details = $detailStmt->get_result();

        $stockStmt = $conn->prepare('UPDATE buku SET stok=stok+? WHERE id_buku=?');
        while ($detail = $details->fetch_assoc()) {
            $stockStmt->bind_param('ii', $detail['jumlah'], $detail['id_buku']);
            $stockStmt->execute();
        }

        // Alasan dikirim ke kotak pesan admin.
        if ($reason !== '') {
            $message = 'Pembatalan Pesanan #' . $orderId . ': ' . $reason;
            $messageStmt = $conn->prepare('INSERT INTO pesan (id_user, pesan, tanggal) VALUES (?, ?, NOW())');
            $messageStmt->bind_param('is', $userId, $message);
            $messageStmt->execute();
        }

        $conn->commit();
        flash('success', 'Pesanan berhasil dibatalkan. Stok telah dikembalikan.' . ($reason !== '' ? ' Alasan telah dikirim ke admin.' : ''));
        header('Location: pesanan.php');
        exit;
    } catch (Throwable $error) {
        $conn->rollback();
        flash('error', $error->getMessage());
    }
}

$pageTitle = 'Batalkan Pesanan';
require 'includes/header.php';
?>

<!-- Form Pembatalan. -->
<div class="card shadow-sm auth-card">
    <div class="card-body p-4">
        <h1 class="h3">Batalkan Pesanan #<?= e($order['id_order']) ?></h1>
        <p>Total pesanan: <strong class="price">Rp<?= number_format($order['total_harga'], 0, ',', '.') ?></strong></p>
        <p class="text-muted">Pembatalan tidak dapat dibatalkan kembali. Stok buku akan dikembalikan.</p>
        <form method="post">
            <input type="hidden" name="id_order" value="<?= e($order['id_order']) ?>">
            <label class="form-label" for="alasan_pembatalan">Alasan pembatalan <span class="text-muted">(opsional, dikirim ke admin)</span></label>
            <textarea class="form-control mb-3" id="alasan_pembatalan" name="alasan_pembatalan" maxlength="1000" rows="4" placeholder="Contoh: alamat pengiriman perlu diperbaiki."><?= e($_POST['alasan_pembatalan'] ?? '') ?></textarea>
            <button class="btn btn-danger">Ya, Batalkan Pesanan</button>
            <a class="btn btn-light" href="pesanan.php">Kembali</a>
        </form>
    </div>
</div>

<?php require 'includes/footer.php'; ?>