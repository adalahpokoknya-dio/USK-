<?php
// Filtering buku sesuai sql.

$pageTitle = 'Katalog Buku';
require 'includes/header.php';

$q = trim($_GET['q'] ?? '');
$cat = (int) ($_GET['kategori'] ?? 0);

$categories = $conn->query(
    'SELECT * FROM kategori ORDER BY nama_kategori'
);

$sql = '
    SELECT b.*, k.nama_kategori
    FROM buku b
    JOIN kategori k ON k.id_kategori = b.id_kategori
    WHERE 1=1
';

$types = '';
$values = [];

if ($q !== '') {
    $sql .= ' AND (
        b.judul_buku LIKE ?
        OR b.penulis LIKE ?
        OR k.nama_kategori LIKE ?
    )';

    $like = '%' . $q . '%';
    $types .= 'sss';
    $values = [$like, $like, $like];
}

if ($cat) {
    $sql .= ' AND b.id_kategori = ?';
    $types .= 'i';
    $values[] = $cat;
}

$sql .= ' ORDER BY b.judul_buku';

$stmt = $conn->prepare($sql);

if ($types) {
    $stmt->bind_param($types, ...$values);
}

$stmt->execute();
$books = $stmt->get_result();
?>

<!-- mencari judul, penulis, atau kategori pada tabel buku. -->

<h1 class="h3 mb-3">Katalog Buku</h1>

<form class="card card-body shadow-sm mb-4" method="get">
    <div class="row g-2">
        <div class="col-md-6">
            <input
                class="form-control"
                name="q"
                placeholder="Cari judul, penulis, atau kategori"
                value="<?= e($q) ?>"
            >
        </div>

        <div class="col-md-4">
            <select class="form-select" name="kategori">
                <option value="">Semua kategori</option>

                <?php while ($k = $categories->fetch_assoc()) : ?>
                    <option
                        value="<?= $k['id_kategori'] ?>"
                        <?= $cat === $k['id_kategori'] ? 'selected' : '' ?>
                    >
                        <?= e($k['nama_kategori']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="col-md-2">
            <button class="btn btn-primary w-100">Cari</button>
        </div>
    </div>
</form>

<div class="row g-4">
    <?php if (!$books->num_rows) : ?>
        <p class="text-muted">Buku tidak ditemukan.</p>
    <?php endif; ?>

    <?php while ($b = $books->fetch_assoc()) : ?>
        <div class="col-sm-6 col-lg-4">
            <div class="card book-card shadow-sm">
                <img
                    class="book-image"
                    src="<?= $b['gambar']
                        ? 'uploads/books/' . e($b['gambar'])
                        : 'https://placehold.co/600x400/eaf7ff/2196d3?text=BookStore' ?>"
                    alt="Sampul buku"
                >

                <div class="card-body">
                    <span class="badge text-bg-info mb-2">
                        <?= e($b['nama_kategori']) ?>
                    </span>

                    <h2 class="h5"><?= e($b['judul_buku']) ?></h2>

                    <p class="small text-muted"><?= e($b['penulis']) ?></p>

                    <p class="price">
                        Rp<?= number_format($b['harga'], 0, ',', '.') ?>
                    </p>

                    <a
                        class="btn btn-outline-primary w-100"
                        href="detail_buku.php?id=<?= $b['id_buku'] ?>"
                    >
                        Detail
                    </a>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<?php require 'includes/footer.php'; ?>