<?php require_once __DIR__ . '/../config/auth.php'; ?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= isset($pageTitle) ? e($pageTitle) . ' | ' : '' ?>BookStore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<!-- Navbar. -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary" href="index.php">📚 BookStore</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="nav">
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <?php
                $menu = [
                    'Beranda' => 'index.php',
                    'Buku' => 'buku.php',
                    'About' => 'about.php',
                    'Kontak' => 'contact.php'
                ];
                foreach ($menu as $nama => $link):
                ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= $link ?>"><?= $nama ?></a>
                    </li>
                <?php endforeach; ?>

                <?php if (!empty($_SESSION['user'])): ?>
                    <li class="nav-item"><a class="nav-link" href="cart.php">Keranjang</a></li>
                    <li class="nav-item"><a class="nav-link" href="pesanan.php">Pesanan Saya</a></li>
                    <li class="nav-item"><span class="nav-link small">Hai, <?= e($_SESSION['user']['nama']) ?></span></li>
                    <li class="nav-item"><a class="btn btn-outline-primary btn-sm ms-lg-2" href="logout.php">Keluar</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="btn btn-primary btn-sm ms-lg-2" href="login.php">Masuk</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<main class="py-4">
    <div class="container">
        <?php if ($m = flash('success')): ?>
            <div class="alert alert-success"><?= e($m) ?></div>
        <?php endif; ?>

        <?php if ($m = flash('error')): ?>
            <div class="alert alert-danger"><?= e($m) ?></div>
        <?php endif; ?>