-- Membuat database aplikasi dengan charset Unicode lengkap.
CREATE DATABASE IF NOT EXISTS bookstore CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bookstore;
-- Tabel akun admin; password seed adalah hash untuk kata sandi "password".
CREATE TABLE admin (id_admin INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL, email VARCHAR(120) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
-- Tabel akun pelanggan dengan password_hash dari PHP.
CREATE TABLE user (id_user INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL, email VARCHAR(120) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, alamat TEXT NOT NULL, nomor_telepon VARCHAR(30) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
-- Tabel master kategori buku.
CREATE TABLE kategori (id_kategori INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nama_kategori VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB;
-- Tabel buku berelasi ke kategori.
CREATE TABLE buku (id_buku INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, id_kategori INT UNSIGNED NOT NULL, judul_buku VARCHAR(200) NOT NULL, penulis VARCHAR(150) NOT NULL, penerbit VARCHAR(150) NOT NULL, tahun_terbit SMALLINT UNSIGNED NOT NULL, harga DECIMAL(12,2) NOT NULL, stok INT UNSIGNED NOT NULL DEFAULT 0, deskripsi TEXT NULL, gambar VARCHAR(255) NULL, CONSTRAINT fk_buku_kategori FOREIGN KEY (id_kategori) REFERENCES kategori(id_kategori) ON UPDATE CASCADE ON DELETE RESTRICT) ENGINE=InnoDB;
-- Keranjang milik user dan satu buku hanya boleh satu baris per user.
CREATE TABLE cart (id_cart INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, id_user INT UNSIGNED NOT NULL, id_buku INT UNSIGNED NOT NULL, jumlah INT UNSIGNED NOT NULL DEFAULT 1, UNIQUE KEY uq_cart_user_buku (id_user,id_buku), CONSTRAINT fk_cart_user FOREIGN KEY (id_user) REFERENCES user(id_user) ON DELETE CASCADE, CONSTRAINT fk_cart_buku FOREIGN KEY (id_buku) REFERENCES buku(id_buku) ON DELETE RESTRICT) ENGINE=InnoDB;
-- Pesan kontak dari user untuk admin.
CREATE TABLE pesan (id_pesan INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, id_user INT UNSIGNED NOT NULL, pesan TEXT NOT NULL, tanggal DATETIME NOT NULL, CONSTRAINT fk_pesan_user FOREIGN KEY (id_user) REFERENCES user(id_user) ON DELETE CASCADE) ENGINE=InnoDB;
-- Header pesanan; dua kolom terakhir mendukung alur upload dan verifikasi pembayaran.
CREATE TABLE orders (id_order INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, id_user INT UNSIGNED NOT NULL, tanggal_order DATETIME NOT NULL, total_harga DECIMAL(12,2) NOT NULL, status ENUM('Menunggu Pembayaran','Menunggu Verifikasi','Disetujui','Ditolak') NOT NULL DEFAULT 'Menunggu Pembayaran', bukti_pembayaran VARCHAR(255) NULL, catatan_admin TEXT NULL, CONSTRAINT fk_order_user FOREIGN KEY (id_user) REFERENCES user(id_user) ON DELETE RESTRICT) ENGINE=InnoDB;
-- Rincian setiap buku di dalam pesanan.
CREATE TABLE order_detail (id_detail INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, id_order INT UNSIGNED NOT NULL, id_buku INT UNSIGNED NOT NULL, jumlah INT UNSIGNED NOT NULL, subtotal DECIMAL(12,2) NOT NULL, CONSTRAINT fk_detail_order FOREIGN KEY (id_order) REFERENCES orders(id_order) ON DELETE CASCADE, CONSTRAINT fk_detail_buku FOREIGN KEY (id_buku) REFERENCES buku(id_buku) ON DELETE RESTRICT) ENGINE=InnoDB;
-- Akun admin awal untuk testing: admin@bookstore.test / password.
INSERT INTO admin (nama,email,password) VALUES ('Administrator','admin@bookstore.test','$2y$10$K1PCdz2QnIV284OH.BK1rOzxUlEoG/f3oacL6YivUdgarcgasCZu2');
-- Data kategori contoh.
INSERT INTO kategori (nama_kategori) VALUES ('Novel'),('Teknologi'),('Bisnis'),('Pendidikan');
-- Data buku contoh dengan relasi kategori.
INSERT INTO buku (id_kategori,judul_buku,penulis,penerbit,tahun_terbit,harga,stok,deskripsi,gambar) VALUES (1,'Laut Bercerita','Leila S. Chudori','KPG',2017,115000,20,'Novel tentang persahabatan dan perjuangan di masa lalu.',NULL),(2,'Dasar Pemrograman PHP','Andi Pratama','Informatika',2024,95000,15,'Panduan praktis memahami PHP untuk pemula.',NULL),(3,'Atomic Habits','James Clear','Gramedia',2019,108000,18,'Strategi membangun kebiasaan kecil yang konsisten.',NULL),(4,'Matematika Dasar','Siti Rahma','Edu Media',2023,75000,25,'Materi matematika dasar yang mudah dipahami.',NULL);
