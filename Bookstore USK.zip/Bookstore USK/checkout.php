<?php
// Checkout membuat pesanan dan menghitung harga .

require_once 'config/auth.php';
requireUser();

$userId = $_SESSION['user']['id'];

$cartStmt = $conn->prepare(
    'SELECT c.*, b.judul_buku, b.harga, b.stok
     FROM cart c
     JOIN buku b ON b.id_buku = c.id_buku
     WHERE c.id_user = ?'
);

$cartStmt->bind_param('i', $userId);
$cartStmt->execute();
$items = $cartStmt->get_result()->fetch_all(MYSQLI_ASSOC);

$total = 0;
foreach ($items as $item) {
    $total += $item['harga'] * $item['jumlah'];
}

// Mengambil alamat akun sebagai alamat awal.

$userStmt = $conn->prepare(
    'SELECT alamat FROM user WHERE id_user = ?'
);

$userStmt->bind_param('i', $userId);
$userStmt->execute();
$user = $userStmt->get_result()->fetch_assoc();

$addressValue = $_POST['alamat_pengiriman'] ?? ($user['alamat'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $method = $_POST['metode_pembayaran'] ?? '';
    $address = trim($_POST['alamat_pengiriman'] ?? '');
    $allowedMethods = ['Transfer Bank', 'Kartu Kredit', 'E-Wallet', 'Bayar di Tempat'];
    $uploadedFile = null;

    try {
        if (!$items) {
            throw new Exception('Keranjang kosong.');
        }

        if (!in_array($method, $allowedMethods, true)) {
            throw new Exception('Pilih metode pembayaran yang tersedia.');
        }

        if ($address === '') {
            throw new Exception('Alamat pengiriman wajib diisi.');
        }

        if (empty($_FILES['bukti']['name']) || $_FILES['bukti']['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Bukti pembayaran wajib diunggah.');
        }

        // Memvalidasi konten bukti sebelum membuat order.

        $file = $_FILES['bukti'];
        $allowedTypes = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp'
        ];

        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);

        if (!isset($allowedTypes[$mime]) || $file['size'] > 2 * 1024 * 1024) {
            throw new Exception('Bukti harus JPG, PNG, atau WEBP maksimal 2 MB.');
        }

        foreach ($items as $item) {
            if ($item['jumlah'] > $item['stok']) {
                throw new Exception('Stok ' . $item['judul_buku'] . ' tidak mencukupi.');
            }
        }

        $uploadedFile = 'payment_' . bin2hex(random_bytes(12)) . '.' . $allowedTypes[$mime];
        $uploadDirectory = __DIR__ . '/uploads/payments';

        if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0775, true)) {
            throw new Exception('Folder upload tidak dapat dibuat.');
        }

        if (!move_uploaded_file($file['tmp_name'], $uploadDirectory . '/' . $uploadedFile)) {
            throw new Exception('Bukti pembayaran gagal disimpan.');
        }

        // Bukti sudah ada sejak awal, sehingga pesanan langsung menunggu verifikasi admin.

        $conn->begin_transaction();

        $status = 'Menunggu Verifikasi';

        $orderStmt = $conn->prepare(
            'INSERT INTO orders
                (id_user, tanggal_order, total_harga, status, metode_pembayaran, alamat_pengiriman, bukti_pembayaran)
             VALUES (?, NOW(), ?, ?, ?, ?, ?)'
        );

        $orderStmt->bind_param('idssss', $userId, $total, $status, $method, $address, $uploadedFile);
        $orderStmt->execute();

        $orderId = $conn->insert_id;

        foreach ($items as $item) {
            $subtotal = $item['harga'] * $item['jumlah'];

            $detailStmt = $conn->prepare(
                'INSERT INTO order_detail (id_order, id_buku, jumlah, subtotal)
                 VALUES (?, ?, ?, ?)'
            );

            $detailStmt->bind_param('iiid', $orderId, $item['id_buku'], $item['jumlah'], $subtotal);
            $detailStmt->execute();

            $stockStmt = $conn->prepare(
                'UPDATE buku SET stok = stok - ? WHERE id_buku = ?'
            );

            $stockStmt->bind_param('ii', $item['jumlah'], $item['id_buku']);
            $stockStmt->execute();
        }

        $clearStmt = $conn->prepare(
            'DELETE FROM cart WHERE id_user = ?'
        );

        $clearStmt->bind_param('i', $userId);
        $clearStmt->execute();

        $conn->commit();

        header('Location: order_success.php?id=' . $orderId);
        exit;

    } catch (Throwable $error) {
        if ($conn->errno) {
            $conn->rollback();
        }

        if ($uploadedFile && file_exists(__DIR__ . '/uploads/payments/' . $uploadedFile)) {
            unlink(__DIR__ . '/uploads/payments/' . $uploadedFile);
        }

        flash('error', $error->getMessage());
    }
}

$pageTitle = 'Checkout';
require 'includes/header.php';
?>

<!-- Form mengirim alamat, pilihan pembayaran mock, dan bukti foto bersama pesanan. -->

<div class="card shadow-sm auth-card">
    <div class="card-body p-4">
        <h1 class="h3">Konfirmasi Checkout</h1>

        <p>
            Total pembayaran:
            <strong class="price">Rp<?= number_format($total, 0, ',', '.') ?></strong>
        </p>

        <p class="text-muted">
            NO REFUND, JIKA INGIN CANCEL ORDER LAKUKAN SEBELUM DIVERIFIKASI ADMIN.
        </p>

        <form method="post" enctype="multipart/form-data">
            <label class="form-label" for="alamat_pengiriman">Alamat pengiriman</label>
            <textarea
                required
                class="form-control mb-3"
                id="alamat_pengiriman"
                name="alamat_pengiriman"
                rows="3"
            ><?= e($addressValue) ?></textarea>

            <label class="form-label" for="metode_pembayaran">Metode pembayaran</label>
            <select required class="form-select mb-3" id="metode_pembayaran" name="metode_pembayaran">
                <option value="">Pilih metode</option>

                <?php foreach (['Transfer Bank', 'Kartu Kredit', 'E-Wallet', 'Bayar di Tempat'] as $method): ?>
                    <option
                        value="<?= e($method) ?>"
                        <?= ($_POST['metode_pembayaran'] ?? '') === $method ? 'selected' : '' ?>
                    >
                        <?= e($method) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label class="form-label" for="bukti">Bukti pembayaran</label>
            <input
                required
                class="form-control mb-2"
                id="bukti"
                type="file"
                name="bukti"
                accept="image/jpeg,image/png,image/webp"
            >

            <small class="text-muted d-block mb-3">
                JPG, PNG, atau WEBP maksimal 2 MB.
            </small>

            <button class="btn btn-primary" <?= !$items ? 'disabled' : '' ?>>
                Kirim Pesanan untuk Verifikasi
            </button>

            <a href="cart.php" class="btn btn-light">Kembali</a>
        </form>
    </div>
</div>

<?php require 'includes/footer.php'; ?>