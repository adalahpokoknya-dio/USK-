// Meminta konfirmasi sebelum tautan/tombol penghapusan
// dengan kelas confirm-delete diproses.

document
    .querySelectorAll('.confirm-delete')
    .forEach(function (element) {

        element.addEventListener(
            'click',
            function (event) {

                if (
                    !confirm(
                        'Hapus data ini? Tindakan tidak dapat dibatalkan.'
                    )
                ) {

                    event.preventDefault();
                }

            }
        );

    });