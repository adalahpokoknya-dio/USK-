<?php
$pageTitle = 'About Us';
require_once 'includes/header.php';
?>

<!-- isi about -->
<div class="auth-card card shadow-sm">
    <div class="card-body p-4">
        <h1 class="h3">Tentang BookStore</h1>

        <p>
            BookStore adalah toko buku online yang membantu pembaca Indonesia
            menemukan buku berkualitas dengan mudah.
        </p>

        <h2 class="h5 mt-4">Visi</h2>

        <p>
            Menjadi sahabat literasi yang terpercaya dan mudah dijangkau.
        </p>

        <h2 class="h5 mt-4">Misi</h2>

        <ul>
            <li>Menyediakan pilihan buku yang relevan.</li>
            <li>Memberikan layanan belanja yang aman dan ramah.</li>
            <li>Mendorong budaya membaca.</li>
        </ul>
    </div>
</div>

<?php
require_once 'includes/footer.php';
?>