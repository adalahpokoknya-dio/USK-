<?php
// Menampilkan pesanan milik user, termasuk status hasil verifikasi admin (diterima/ditolak).

require_once 'config/auth.php';
requireUser();

$userId = $_SESSION['user']['id'];

$stmt = $conn->prepare(
    'SELECT id_order, tanggal_order, total_harga, status, metode_pembayaran, bukti_pembayaran
     FROM orders
     WHERE id_user = ?
     ORDER BY tanggal_order DESC'
);

$stmt->bind_param('i', $userId);
$stmt->execute();

$orders = $stmt->get_result();
$pageTitle = 'Pesanan Saya';

require 'includes/header.php';
?>

<!-- Riwayat order memungkinkan user memantau hasil verifikasi admin (diterima, di tolak, menunggu verifikasi) -->

<h1 class="h3 mb-3">Pesanan Saya</h1>

<div class="card shadow-sm table-responsive">
    <table class="table mb-0">
        <thead>
            <tr>
                <th>Nomor</th>
                <th>Tanggal</th>
                <th>Metode</th>
                <th>Total</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!$orders->num_rows): ?>
                <tr>
                    <td colspan="6" class="text-center text-muted py-4">
                        Belum ada pesanan.
                        <a href="buku.php">Mulai belanja</a>.
                    </td>
                </tr>
            <?php endif; ?>

            <?php while ($order = $orders->fetch_assoc()): ?>
                <?php
                $badge = $order['status'] === 'Disetujui'
                    ? 'success'
                    : (in_array($order['status'], ['Ditolak', 'Dibatalkan'], true) ? 'danger' : 'info');

                $statusLabel = $order['status'] === 'Disetujui'
                    ? 'Diterima'
                    : $order['status'];
                ?>

                <tr>
                    <td>#<?= e($order['id_order']) ?></td>
                    <td><?= e($order['tanggal_order']) ?></td>
                    <td><?= e($order['metode_pembayaran'] ?: '-') ?></td>
                    <td>Rp<?= number_format($order['total_harga'], 0, ',', '.') ?></td>
                    <td>
                        <span class="badge text-bg-<?= $badge ?>">
                            <?= e($statusLabel) ?>
                        </span>
                    </td>
                    <td>
                        <a class="btn btn-sm btn-outline-primary" href="order_success.php?id=<?= e($order['id_order']) ?>">
                            Detail
                        </a>

                        <?php if ($order['status'] === 'Disetujui'): ?>
                            <!-- Tombol bon hanya tampil setelah admin ferivikasi. -->
                            <a class="btn btn-sm btn-success mt-1" href="receipt_transaksi.php?id=<?= e($order['id_order']) ?>">
                                Bon PDF
                            </a>
                        <?php endif; ?>

                        <?php if (in_array($order['status'], ['Menunggu Pembayaran', 'Menunggu Verifikasi'], true)): ?>
                            <!-- Pembatalan hanya tersedia sebelum ferivikasi admin. -->
                            <a class="btn btn-sm btn-outline-danger mt-1" href="batalkan_pesanan.php?id=<?= e($order['id_order']) ?>">
                                Batalkan
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php require 'includes/footer.php'; ?>