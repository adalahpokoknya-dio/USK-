<?php
// Mengambil satu buku berdasarkan data; redirect bila tdk tersedia.

require_once 'config/auth.php';

$id = (int) ($_GET['id'] ?? 0);

$stmt = $conn->prepare(
    'SELECT b.*, k.nama_kategori
     FROM buku b
     JOIN kategori k ON k.id_kategori = b.id_kategori
     WHERE b.id_buku = ?'
);

$stmt->bind_param('i', $id);
$stmt->execute();

$b = $stmt->get_result()->fetch_assoc();

if (!$b) {
    flash('error', 'Buku tidak ditemukan.');
    header('Location: buku.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireUser();

    $jumlah = max(1, (int) ($_POST['jumlah'] ?? 1));

    if ($jumlah > $b['stok']) {
        flash('error', 'Jumlah melebihi stok.');
    } else {
        $uid = $_SESSION['user']['id'];

        $check = $conn->prepare(
            'SELECT id_cart, jumlah
             FROM cart
             WHERE id_user = ? AND id_buku = ?'
        );

        $check->bind_param('ii', $uid, $id);
        $check->execute();

        $old = $check->get_result()->fetch_assoc();

        if ($old) {
            $new = $old['jumlah'] + $jumlah;

            $up = $conn->prepare(
                'UPDATE cart SET jumlah = ? WHERE id_cart = ?'
            );

            $up->bind_param('ii', $new, $old['id_cart']);
            $up->execute();
        } else {
            $add = $conn->prepare(
                'INSERT INTO cart (id_user, id_buku, jumlah)
                 VALUES (?, ?, ?)'
            );

            $add->bind_param('iii', $uid, $id, $jumlah);
            $add->execute();
        }

        flash('success', 'Buku ditambahkan ke keranjang.');
        header('Location: cart.php');
        exit;
    }
}

$pageTitle = $b['judul_buku'];
require 'includes/header.php';
?>

<!-- Detail buku dan tombol menambahkan item ke tabel cart. -->

<div class="row g-4">
    <div class="col-md-5">
        <img
            class="img-fluid rounded shadow-sm book-image"
            style="height:400px"
            src="<?= $b['gambar'] ? 'uploads/books/' . e($b['gambar']) : 'https://placehold.co/600x400/eaf7ff/2196d3?text=BookStore' ?>"
            alt="Sampul <?= e($b['judul_buku']) ?>"
        >
    </div>

    <div class="col-md-7">
        <span class="badge text-bg-info">
            <?= e($b['nama_kategori']) ?>
        </span>

        <h1 class="mt-2"><?= e($b['judul_buku']) ?></h1>

        <p class="text-muted">
            oleh <?= e($b['penulis']) ?> ·
            <?= e($b['penerbit']) ?>
            (<?= e($b['tahun_terbit']) ?>)
        </p>

        <h2 class="price h3">
            Rp<?= number_format($b['harga'], 0, ',', '.') ?>
        </h2>

        <p>Stok tersedia: <strong><?= e($b['stok']) ?></strong></p>
        <p><?= nl2br(e($b['deskripsi'])) ?></p>

        <?php if ($b['stok'] > 0) : ?>
            <form method="post" class="d-flex gap-2">
                <input
                    type="number"
                    name="jumlah"
                    class="form-control"
                    style="max-width:100px"
                    min="1"
                    max="<?= e($b['stok']) ?>"
                    value="1"
                >
                <button class="btn btn-primary">Tambah ke Keranjang</button>
            </form>
        <?php else : ?>
            <p class="text-danger">Stok habis.</p>
        <?php endif; ?>
    </div>
</div>

<?php require 'includes/footer.php'; ?>